Title: Support
Slug: support
Author: Truong Phan
Date: June 1 2020

#### 1. About

It's a service to help you convert YouTube (and more sites are coming) video to MP3, then download. For now, the service only support videos with less than 10 minutes.

#### 2. Usage

It's really easy, put your link to the form, the hit Submit button.

#### 3. Plan

Yup, I am working more fascinating features, just sign up and I will get you informed.
